#include "runtime/resource/res_type/components/motor.h"

#include "runtime/core/base/macro.h"

namespace Pilot
{
    MotorComponentRes::~MotorComponentRes() {  }
} // namespace Pilot